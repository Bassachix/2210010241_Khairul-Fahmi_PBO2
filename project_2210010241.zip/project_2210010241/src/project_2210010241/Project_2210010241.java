/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package project_2210010241;
import GUI.mainFrame;

/**
 *
 * @author USER
 */
public class Project_2210010241 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        new mainFrame().setVisible(true);
        
        
    }
    
}
